-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 54.180.163.135    Database: talkie
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vocabulary`
--

DROP TABLE IF EXISTS `vocabulary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vocabulary` (
  `vocabulary_seq` int NOT NULL AUTO_INCREMENT,
  `vocabulary_score` double DEFAULT NULL,
  `conversation_seq` int NOT NULL,
  PRIMARY KEY (`vocabulary_seq`),
  UNIQUE KEY `UK1monq7a5m8othrrykoy4lysv2` (`conversation_seq`),
  CONSTRAINT `FKpihwnmjug3hswurxfousku6dx` FOREIGN KEY (`conversation_seq`) REFERENCES `conversation_analytics` (`conversation_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulary`
--

LOCK TABLES `vocabulary` WRITE;
/*!40000 ALTER TABLE `vocabulary` DISABLE KEYS */;
INSERT INTO `vocabulary` VALUES (1,4.5,145),(2,4.8,146),(3,5,147),(4,4.7,148),(5,4.9,149),(7,4.6,150),(8,4.5,151),(9,4.8,152),(10,4.7,153),(11,4.9,154),(12,4.8,155),(13,4.6,156),(14,4.7,157),(15,4.9,158),(16,4.8,159),(17,4.8,160),(18,4.9,161),(19,4.7,162),(20,4.8,163),(21,4.9,164),(22,4.7,165),(23,4.8,166),(24,4.9,167),(25,4.8,168),(26,4.7,169),(27,4.8,170),(28,4.8,171),(29,4.9,172),(30,4.5,173),(31,4.8,174),(32,4.6,175),(33,4.9,176),(34,4.7,177),(35,4.9,178),(36,4.5,179),(37,4.8,180),(38,4.9,181),(39,4.7,182),(40,4.8,183),(41,4.9,184),(42,4.9,185),(43,4.8,186),(44,4.7,187),(45,4.9,188),(46,4.8,189),(47,4.7,190),(48,4.6,191),(49,4.9,192),(50,4.8,193),(51,4.9,194),(52,5,195),(53,4.7,196),(54,4.9,197),(55,4.8,198),(56,4.7,199),(57,4.9,200),(58,4.8,201),(59,4.9,202),(60,4.7,203),(61,5,204),(62,4.8,205),(63,4.7,206),(64,4.9,207),(65,5,208),(66,5,209),(67,4.9,210),(68,4.6,211),(69,4.9,212),(70,4.7,213),(71,4.8,214),(72,4.8,215),(73,4.9,216),(74,4.7,217),(75,2.67,218),(76,3,219),(77,3,220),(78,4,221);
/*!40000 ALTER TABLE `vocabulary` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 13:58:58
