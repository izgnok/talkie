-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 54.180.163.135    Database: talkie
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `answer` (
  `answer_seq` int NOT NULL AUTO_INCREMENT,
  `content` varchar(3000) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `question_seq` int NOT NULL,
  PRIMARY KEY (`answer_seq`),
  UNIQUE KEY `UKc4xddf4m8qqg2u2qm5sxjhcu2` (`question_seq`),
  CONSTRAINT `FK1k9vsittgtmm3qixxtegr1wsu` FOREIGN KEY (`question_seq`) REFERENCES `question` (`question_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` VALUES (1,'손을 잘 씻으라고 했어','2024-11-06 16:30:00.000000',97),(2,'친구들과 간식을 나눠 먹었어.','2024-11-03 00:02:22.000000',98),(3,'교실에서 공룡 그림을 그렸어.','2024-11-03 15:42:40.000000',99),(4,'만들기 시간에 종이로 비행기를 접었어.','2024-11-05 14:28:09.000000',100),(5,'새로운 동화를 듣고 상상했어.','2024-11-06 12:20:15.000000',101),(6,'친구가 도와줘서 그림을 완성했어.','2024-11-08 16:28:31.000000',102),(7,'새로운 게임을 배워서 신났어.','2024-11-10 02:21:52.000000',103),(8,'선생님이 책 읽어주셔서 좋았어.','2024-11-10 03:24:39.000000',104),(9,'블록 놀이로 큰 집을 만들었어.','2024-11-11 14:58:29.000000',105),(10,'점심에 김밥을 먹었는데 맛있었어.','2024-11-11 15:54:53.000000',106),(11,'모래놀이 시간에 성을 쌓았어.','2024-11-11 22:14:54.000000',107),(12,'그네를 타면서 가장 행복했어.','2024-11-12 00:57:07.000000',108),(13,'친구랑 같이 그림을 그렸어.','2024-11-12 19:19:37.000000',109),(14,'운동장에서 공놀이를 했어.','2024-11-15 07:47:02.000000',110),(15,'책 읽는 시간이 편안하고 좋았어.','2024-11-16 16:19:47.000000',111),(16,'운동장에서 달리기 시합을 했어.','2024-11-16 22:25:00.000000',112),(17,'미끄럼틀에서 재밌게 놀았어.','2024-11-17 08:15:43.000000',113),(18,'노래 부르는 시간이 제일 좋았어.','2024-11-18 02:00:16.000000',114),(19,'노래를 같이 불러서 기뻤어.','2024-11-18 06:00:59.000000',115),(20,'선생님이 칭찬해주셔서 기분이 좋았어.','2024-11-18 08:10:18.000000',116),(21,'친구가 내 그림을 보고 멋지다고 했어.','2024-11-18 14:32:24.000000',117);
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 13:58:59
