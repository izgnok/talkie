-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 54.180.163.135    Database: talkie
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `week_analytics`
--

DROP TABLE IF EXISTS `week_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `week_analytics` (
  `week_seq` int NOT NULL AUTO_INCREMENT,
  `emotion_summary` varchar(3000) NOT NULL,
  `month` int NOT NULL,
  `vocabulary_summary` varchar(3000) NOT NULL,
  `week` int NOT NULL,
  `word_cloud_summary` varchar(3000) NOT NULL,
  `year` int NOT NULL,
  `user_seq` int NOT NULL,
  `count_summary` varchar(3000) NOT NULL,
  PRIMARY KEY (`week_seq`),
  KEY `FKfqtly5nleis1s4gaudrb22lcr` (`user_seq`),
  CONSTRAINT `FKfqtly5nleis1s4gaudrb22lcr` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `week_analytics`
--

LOCK TABLES `week_analytics` WRITE;
/*!40000 ALTER TABLE `week_analytics` DISABLE KEYS */;
INSERT INTO `week_analytics` VALUES (6,'이번 주에 아이는 주로 기쁨과 사랑을 많이 느꼈습니다.',11,'어휘력이 꾸준히 향상되고 있습니다.',2,'아이가 이번 주에 장난감, 가족, 놀이에 대한 관심을 많이 보였습니다.',2024,1,'이번 주에는 일요일과 월요일에 대화 횟수가 많았고, 금요일과 토요일에 대화 횟수가 감소하는 경향이 있었습니다. 가장 많이 대화한 날은 일요일이었습니다.'),(7,'아이의 감정 점수를 보면, 기쁨과 사랑에서 높은 반응을 보였고, 슬픔과 두려움의 반응은 낮았습니다. 이는 주로 긍정적인 감정을 더 강하게 느끼는 경향이 있음을 나타냅니다. 아이에게 긍정적인 감정을 키우기 위해, 즐거웠던 일에 대해 이야기해 보세요.',11,'아이의 어휘력 점수는 꾸준히 향상되어, 주 초반보다 후반에 더 높은 점수를 보였습니다. 주 평균 점수는 3.87점으로 동나이 평균보다 살짝 낮은 점수를 기록했어요. 아이와 함께 새로운 단어를 찾아보는 활동을 추천합니다.',3,'아이의 이번 주 워드 클라우드를 보면 \'공원\'이 가장 많이 언급되었고, 그 다음으로 \'자전거\', \'게임\', \'운동\', \'아이\'와 관련된 주제들이 자주 언급되었어요. 아이가 자연에서 활동하며 즐거움을 느끼는 것을 좋아하는 경향이 보입니다. 주말에 함께 공원에서 자전거를 타거나 게임 활동을 즐기며 시간을 보내보시는 건 어떨까요?',2024,1,'아이가 이번 주에 총 42번의 대화를 나누었어요. 하루 평균 대화 횟수는 약 6번이었어요. 대화 횟수는 금요일에 가장 많았고, 화요일에 가장 적었어요. 아이가 토키와 친밀도를 쌓을 수 있도록 매일 흥미로운 주제를 찾아 이야기를 나눠보시는 건 어떨까요?'),(8,'이번 주에 아이는 주로 기쁨과 사랑을 많이 느꼈습니다.',11,'어휘력이 꾸준히 향상되고 있습니다.',4,'아이가 이번 주에 요가, 낚시, 음악, 운동회에 대한 관심을 많이 보였습니다.',2024,1,'이번 주에는 일요일과 월요일에 대화 횟수가 많았고, 금요일과 토요일에 대화 횟수가 감소하는 경향이 있었습니다. 가장 많이 대화한 날은 일요일이었습니다.');
/*!40000 ALTER TABLE `week_analytics` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 13:58:59
