-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 54.180.163.135    Database: talkie
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question` (
  `question_seq` int NOT NULL AUTO_INCREMENT,
  `content` varchar(3000) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `is_active` bit(1) NOT NULL,
  `user_seq` int NOT NULL,
  PRIMARY KEY (`question_seq`),
  KEY `FKbhuqpcgdgq2wifb2j9k1e60t6` (`user_seq`),
  CONSTRAINT `FKbhuqpcgdgq2wifb2j9k1e60t6` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (97,'오늘 유치원에서 뭘 배웠어','2024-11-06 16:30:00.000000',_binary '\0',1),(98,'오늘 운동장에서 가장 즐거웠던 일은 뭐야?','2024-11-03 00:02:22.000000',_binary '\0',1),(99,'수업 시간에 힘들었던 일은 있었어?','2024-11-03 15:42:40.000000',_binary '\0',1),(100,'다른 친구들에게 들은 재미있는 이야기가 있어?','2024-11-05 14:28:09.000000',_binary '\0',1),(101,'오늘 친구들과 무엇에 대해 이야기했어?','2024-11-06 12:20:15.000000',_binary '\0',1),(102,'책 읽기 시간에 무슨 책을 읽었어?','2024-11-08 16:28:31.000000',_binary '\0',1),(103,'오늘 학교에서 배운 것 중 가장 기억에 남는 건 뭐야?','2024-11-10 02:21:52.000000',_binary '\0',1),(104,'점심시간에 무슨 음식을 먹었어?','2024-11-10 03:24:39.000000',_binary '\0',1),(105,'수업 중에 어떤 노래를 불렀어?','2024-11-11 14:58:29.000000',_binary '\0',1),(106,'선생님이 어떤 이야기를 해주셨어?','2024-11-11 15:54:53.000000',_binary '\0',1),(107,'유치원에서 만든 것 중에 집에 가져가고 싶은 게 있어?','2024-11-11 22:14:54.000000',_binary '\0',1),(108,'너가 생각하는 오늘의 최고의 순간은 뭐야?','2024-11-12 00:57:07.000000',_binary '\0',1),(109,'오늘 유치원에서 재미있는 일이 있었어?','2024-11-12 19:19:37.000000',_binary '\0',1),(110,'어떤 게임을 하면서 가장 즐거웠어?','2024-11-15 07:47:02.000000',_binary '\0',1),(111,'운동장에서 어떤 놀이를 했어?','2024-11-16 16:19:47.000000',_binary '\0',1),(112,'미술 시간에 뭘 만들었어?','2024-11-16 22:25:00.000000',_binary '\0',1),(113,'새로운 친구가 생겼어?','2024-11-17 08:15:43.000000',_binary '\0',1),(114,'오늘 무슨 놀이를 했어?','2024-11-18 02:00:16.000000',_binary '\0',1),(115,'놀이 시간에 누가 너를 도와줬어?','2024-11-18 06:00:59.000000',_binary '\0',1),(116,'오늘 배운 단어 중 기억에 남는 게 뭐야?','2024-11-18 08:10:18.000000',_binary '\0',1),(117,'그림 시간에 어떤 걸 그렸어?','2024-11-18 14:32:24.000000',_binary '\0',1);
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 13:58:57
