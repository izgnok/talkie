-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 54.180.163.135    Database: talkie
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `week_word_cloud`
--

DROP TABLE IF EXISTS `week_word_cloud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `week_word_cloud` (
  `week_word_cloud_seq` int NOT NULL AUTO_INCREMENT,
  `count` int NOT NULL,
  `word` varchar(255) NOT NULL,
  `week_seq` int NOT NULL,
  PRIMARY KEY (`week_word_cloud_seq`),
  KEY `FK3b9gissl529rot11igitgch81` (`week_seq`),
  CONSTRAINT `FK3b9gissl529rot11igitgch81` FOREIGN KEY (`week_seq`) REFERENCES `week_analytics` (`week_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `week_word_cloud`
--

LOCK TABLES `week_word_cloud` WRITE;
/*!40000 ALTER TABLE `week_word_cloud` DISABLE KEYS */;
INSERT INTO `week_word_cloud` VALUES (31,12,'공원',7),(32,10,'자전거',7),(33,7,'게임',7),(34,5,'운동',7),(35,6,'아이',7),(36,10,'장난감',6),(37,7,'가족',6),(38,5,'놀이',6),(39,3,'동물',6),(40,8,'친구',6),(70,5,'요가',8),(71,3,'비둘기',8),(72,2,'나무',8),(73,4,'낚시',8),(74,6,'물고기',8),(75,4,'바다',8),(76,8,'음악',8),(77,3,'클래식',8),(78,2,'재즈',8),(79,5,'운동회',8),(80,4,'달리기',8),(81,3,'높이뛰기',8);
/*!40000 ALTER TABLE `week_word_cloud` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 13:58:58
